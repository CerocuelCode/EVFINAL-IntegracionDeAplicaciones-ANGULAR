export interface Platillo {
  id?: string;
  nombre: string;
  ingredientes: string;
  precio: number;
  imagen: string;
}
